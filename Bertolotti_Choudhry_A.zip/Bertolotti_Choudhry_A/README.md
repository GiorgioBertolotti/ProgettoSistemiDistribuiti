# Progetto sistemi distribuiti - Traccia A

L'archivio contiene due cartelle per le versioni base e upgrade 1 della traccia A.  

## Versione base

La versione base del progetto rispecchia le indicazioni fornite nella traccia.  
Abbiamo deciso di implementare la classe Automobilista come Thread e utilizzare la classe Parcheggiatore solo per l'esecuzione dello sleep per simulare i tempi d'attesa delle azioni di parcheggio e ritiro dell'automobile.

## Upgrade 1

Per implementare l'upgrade 1 abbiamo fatto sostanziali modifiche alla versione base.  
Per permettere un miglior funzionamento del programma, abbiamo deciso di implementare 4 tipologie di chiamate al server:

- *richiestaParcheggi*: il server ritorna al chiamante la lista di oggetti Parcheggio non pieni serializzata, essa contiene lo stato effettivo del parcheggio (parcheggiatori disponibili, posti occupati, automobili, ecc...);
- *statoParcheggiatore-x-y-z*: utilizzata per segnalare al server quando un parcheggiatore diventa occupato/si libera, *x* è l'indice del parcheggio, *y* è l'index del parcheggiatore e *z* ha valore 1/0 in base a se il parcheggiatore è libero/occupato;
- *getStatoParcheggiatori-x*: ritorna al chiamante l'array di oggetti Parcheggiatore del Parcheggio *x*, con relativo stato (libero/occupato);
- *aggiornaStatoParcheggio*: riceve dal chiamante un'oggetto di tipo Parcheggio serializzato, per permettere l'aggiornamento dello stato di un parcheggio (parcheggiatori, automobili, ecc...).

In sintesi, tutte le azioni fatte da Parcheggio vanno a sincronizzare lo stato di tale Parcheggio sul server.

## Per avviare

### Versione base

Caricare in Eclipse il folder *Project* ed eseguire la classe *Main*.

### Upgrade 1

Dopo aver caricato in Eclipse il folder *ProjectUpgrade1*, eseguire prima la classe *Server* e poi la classe *Main*.